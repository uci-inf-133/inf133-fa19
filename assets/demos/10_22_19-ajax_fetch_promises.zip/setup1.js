/*TODO:
 - Use a promise to print "Hello from the future!" 5 seconds after the JavaScript loads by sending the string back as the result of a promise.
*/


console.log("Hello from the present!");