import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
//TODO: import DeviceMotion and DeviceMotionAccelerationData from @ionic-native/device-motion/ngx

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

	//TODO: Inject DeviceMotion
	constructor(private platform:Platform) {
		//TODO: when the platform is ready, watch acceleration every second and bind it to a string to display
	}

}
