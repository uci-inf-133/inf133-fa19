import { Component } from '@angular/core';
import { LocalNotifications, ILocalNotification } from '@ionic-native/local-notifications/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(private localNotifications:LocalNotifications) {
  	
  }

  scheduleNotification() {
    //TODO: use this.localNotifcations.schedule to schedule a notification based on the inputted delay.
    //try the "at" argument, and if that fails, use setTimeout()
  }

}
