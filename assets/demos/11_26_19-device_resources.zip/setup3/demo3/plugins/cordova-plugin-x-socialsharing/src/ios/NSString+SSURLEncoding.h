#import <Foundation/Foundation.h>

@interface NSString (SSURLEncoding)
@property (readonly) NSString *SSURLEncodedString;
@end
