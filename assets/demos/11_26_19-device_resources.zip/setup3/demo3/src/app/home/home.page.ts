import { Component } from '@angular/core';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	textMessage:string;
	phoneNumber:string

  constructor(private social:SocialSharing) {}

  sendText() {
  	//TODO: take the text message and phone number and share via SMS
  }

}
