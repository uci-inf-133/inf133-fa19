import { Component } from '@angular/core';
import { LocalNotifications, ILocalNotification } from '@ionic-native/local-notifications/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	delay:number;

  constructor(private localNotifications:LocalNotifications) {
  	
  }

  scheduleNotification() {
  	setTimeout(() => {
  		this.localNotifications.schedule({
		   text: 'Time to log your sleepiness!',
		   sound: null
		});
  	}, this.delay*1000);
  }

}
