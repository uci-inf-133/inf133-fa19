import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { DeviceMotion, DeviceMotionAccelerationData } from '@ionic-native/device-motion/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

	acceleration:string = 'No acceleration data';

	constructor(private platform:Platform, private deviceMotion:DeviceMotion) {
		this.platform.ready().then(() => {
			this.deviceMotion.watchAcceleration({frequency: 1000}).subscribe((acc) => {
				this.acceleration = acc.x + ' ' + acc.y + ' ' + acc.z;
			});
		});
	}

}
