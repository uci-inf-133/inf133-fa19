import { Component } from '@angular/core';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private storage:Storage) {
  	this.storage.get('username').then((usr) => {
  		if(usr) {
  			this.username = usr;
  			this.loggedIn = true;
  		}
  	});
  }

  logIn() {
  	this.storage.set("username", this.username).then(() => {
  		this.loggedIn = true;
  	})
  }
}
