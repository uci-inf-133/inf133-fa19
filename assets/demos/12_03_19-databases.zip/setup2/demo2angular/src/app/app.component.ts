import { Component } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private db:AngularFirestore) {
  	//TODO: copy the constructor from Ionic to update the loggedIn and username fields
  }


}
