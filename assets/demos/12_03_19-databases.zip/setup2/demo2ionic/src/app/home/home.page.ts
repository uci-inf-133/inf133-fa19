import { Component } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, DocumentData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private db:AngularFirestore) {
    //TODO: get the username doc from the users collection.
    //If the doc exists, update the username and loggedIn fields
  }

  logIn() {
    //TODO: store the username in the username doc
  }
}
