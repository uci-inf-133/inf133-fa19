import { Component } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, DocumentData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private db:AngularFirestore) {
  	this.db.collection('users').doc('username').get().subscribe((data) => {
  		var doc = data.data();
  		if(doc && doc.username) {
  			this.username = doc.username;
  			this.loggedIn = true;
  		}
  	});
  }

  logIn() {
  	this.db.collection('users').doc('username').set({username:this.username}).then(() => {
  		this.loggedIn = true;
  	});
  }
}
