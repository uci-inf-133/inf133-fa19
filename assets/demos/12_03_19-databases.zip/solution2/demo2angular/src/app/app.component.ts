import { Component } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private db:AngularFirestore) {
  	this.db.collection('users').doc('username').get().subscribe((data) => {
  		var doc = data.data();
  		if(doc && doc.username) {
  			this.username = doc.username;
  			this.loggedIn = true;
  		}
  	});
  }


}
