import { Component } from '@angular/core';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	loggedIn:boolean = false;
	username:string = undefined;

  constructor(private storage:Storage) {
    //TODO: try to get the username from storage.
    //If a value is returned, update the username field and set loggedIn to true.
  	this.storage.get('username').then((usr) => {
  		if(usr) {
  			this.username = usr;
  			this.loggedIn = true;
  		}
  	});
  }

  logIn() {
    //TODO: set the username in the storage and set loggedIn to true.
  	this.storage.set("username", this.username).then(() => {
  		this.loggedIn = true;
  	})
  }
}
