import { Injectable } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Injectable()
export class GroceriesService {
  //If there is time, teach about event emitter with the demo part2 project
  //this emitter is an observable, and will shoot a change to anyone who subscribes to it (that is why it is not a private property)
  groceriesChanged = new EventEmitter<String[]>();

  //private because we whant this service to be a "source of truth" about the list, only it can change the list, based on actions called to it
  private grocerielist:String[] = [
    'potato',
    'melon'
  ];

  constructor() { }

  //slice because it is a copy, we don't whant to hand out a real reference to the grocerielist
  public getGrocerieList():String[]{
    return this.grocerielist.slice();
  }

  public addItem(item: String){
    this.grocerielist.push(item);
    //shoot the emition of a new list, since it was changed
    this.groceriesChanged.emit(this.grocerielist.slice());
  }

}
