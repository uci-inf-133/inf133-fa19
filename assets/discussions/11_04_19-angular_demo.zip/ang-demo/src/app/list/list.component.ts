import { Component, OnInit } from '@angular/core';
import { GroceriesService } from '../groceries-service.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  list:String[];

  //Inject service
  constructor(private groceriesService: GroceriesService) { }

  ngOnInit() {
    //First show without event emitter to show how the list component dosn't update if the other component changes the list
    this.list = this.groceriesService.getGrocerieList();

    //then show with event subscription in this component to show that it will observe for any changes
    this.groceriesService.groceriesChanged
        .subscribe(
          (itemList: String[]) =>{
            this.list = itemList;
          }
       )
  }

}
