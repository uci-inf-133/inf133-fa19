import { Component } from '@angular/core';
import { TodoService } from '../todo.service';
import { NavController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  task:String='';
  constructor(private service: TodoService, public navCtrl: NavController, public notification: ToastController) {}

  addTask() {
    console.log(this.task);
    this.service.addTask(this.task);

    this.notification.create({
      message: this.task+' was added',
      duration: 2000
    }).then((toast) => {
      toast.present();
    });

  }

  goToList(){
    this.navCtrl.navigateForward("/list");
  }

}
