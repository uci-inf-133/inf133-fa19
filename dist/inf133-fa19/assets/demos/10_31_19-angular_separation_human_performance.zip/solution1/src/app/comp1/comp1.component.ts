import { Component, OnInit } from '@angular/core';
import { TwitterService } from '../twitter.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {
  tweets:string[];

  constructor(private twitter:TwitterService) { }

  ngOnInit() {
    this.twitter.getTweets().then((tweets) => {
      this.tweets = tweets['statuses'].map((tweet) => {
        return tweet.text;
      });
    });
  }

}
