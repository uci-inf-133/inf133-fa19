import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'solution1';
  website = 'https://inf133-fa19.depstein.net/';
  slack = 'https://uci-inf133-fa19.slack.com/';
}
