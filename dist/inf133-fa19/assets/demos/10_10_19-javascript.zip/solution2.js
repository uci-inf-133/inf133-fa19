/*TODO:
- use setTimeout() to print "Hello from the future!" 5 seconds after the page is loaded
- alternate logging "ticks" and "tocks" every one second, creating a named function for tick and an anonymous function for tock
setTimeout takes two arguments: a callback function, time in MS until function should be called
https://www.w3schools.com/jsref/met_win_settimeout.asp
*/

function helloFromTheFuture() {
	console.log("Hello from the future!");
}

setTimeout(helloFromTheFuture, 5000);

function tick() {
	console.log('tick');
	setTimeout(() => {
		console.log('tock');
		setTimeout(tick, 1000);
	}, 1000);
}

setTimeout(tick, 1000);