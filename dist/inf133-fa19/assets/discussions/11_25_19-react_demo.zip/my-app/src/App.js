import React from 'react';
import logo from './logo.svg';
import './App.css';
import HelloMessage from './HelloMessage';
import Counter from './Counter';
import CounterFunc from './CounterFunc';

const App = () => {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <HelloMessage name='class'/>
        <Counter />
        <CounterFunc />
      </header>
    </div>
  );
}

export default App;