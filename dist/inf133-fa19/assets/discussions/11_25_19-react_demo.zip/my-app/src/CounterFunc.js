import React, { useState } from 'react';
import './App.css';

const CounterFunc = () => {
  const [count, setCount] = useState(0);

  const add = () => {
    setCount(count + 1);
  }

  return (
    <div>
      <p>You clicked {count} times</p>
      <button 
      onClick={
        () => add()
      }>
        Click me
      </button>
    </div>
  );
}

export default CounterFunc;

