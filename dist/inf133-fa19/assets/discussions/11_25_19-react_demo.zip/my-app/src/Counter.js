import React from 'react';

class Counter extends React.Component {
    constructor(props) {
        super(props);
        this.addOne = this.addOne.bind(this);
        this.state = {counter: 0};
    }
    addOne(){
        this.setState({counter: this.state.counter+1});
    }
 render() {
   return (
     <div>
        <p>{this.state.counter}</p>
       <button onClick={this.addOne}>+</button>
     </div>
   );
 }
}
export default Counter;