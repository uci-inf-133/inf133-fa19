import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import GroceryList from './components/GroceryList';
import Input from './components/Input';
import BAppBar from './components/AppBar';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: '#979797',
    height: '700px'

  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}));

export default function App() {
  const classes = useStyles();

  let [list, setList] = useState(['tomato', 'potato']);

  const addItem = (item) => {
    setList([...list, item]);
  }

  return (
    <div>
      <BAppBar />
      <div className={classes.root}>
        <Grid container spacing={3}>
        <Grid item xs={6}>
            <GroceryList list={list} />
          </Grid>
          <Grid item xs={6}>
            <Input addItem={addItem}></Input>
          </Grid>
        </Grid>
      </div>
    </div>
  );
}