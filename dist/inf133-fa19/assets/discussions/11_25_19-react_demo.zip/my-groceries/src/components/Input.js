import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';



const useStyles = makeStyles(theme => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
    },
}));

export default function Input(props) {
    const classes = useStyles();
    const [inputValue, setInput] = useState('');

    const handleSubmit = (evt) => {
        evt.preventDefault(); //prevents page from reloading after a form submit
        props.addItem(inputValue); //uses the method passed by the parent compoent addItem with the input value as a parameter
        setInput(''); //resets input to be ready for another item.
    }

    return (
        <div className={classes.root}>
            <form onSubmit={handleSubmit}>
                <Paper className={classes.paper}>
                    <Grid item xs={12}>
                        <TextField
                            id="outlined-helperText"
                            label="Input grocery item"
                            className={classes.textField}
                            margin="normal"
                            variant="outlined"
                            value={inputValue}
                            onChange={e => setInput(e.target.value)}  //uses an anonymous arrowfunction so that the setInput method will only be called when the event happens
                        />
                    </Grid>
                    <Grid item xs={12}>
                        {//button submits the form
                        }
                        <Button variant="contained" color="secondary" type="submit"> 
                            Add 
                    </Button>
                    </Grid>
                </Paper>
            </form>
        </div>
    );
}