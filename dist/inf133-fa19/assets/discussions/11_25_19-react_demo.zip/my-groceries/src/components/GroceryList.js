import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';

const useStyles = makeStyles(theme => ({
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
    },
}));

export default function GroceryList(props) {
    const classes = useStyles();

    return (
        <div >
            <Paper className={classes.paper}>
                <h1> My Grocery list: </h1>
                <ul>
                    {props.list.map((item) => {
                        return <li>{item}</li>
                    })}
                </ul>
            </Paper>
        </div>
    );
}