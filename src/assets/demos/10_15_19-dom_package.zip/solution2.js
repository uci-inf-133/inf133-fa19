/*
	- Use jQuery to add a new paragraph each time the button is clicked. Give it the text "paragraph #", where # is the paragraph number.
	- Have each new paragraph slide in when it gets added.
*/

//jQuery uses document.ready to designate when the page has loaded
$(document).ready(()=> {
	var paragraphNumber = 1;

	$('#newParagraph').click((event) => {
		console.log('Adding a paragraph');
		
		//Treat the tag as a string
		//var newP = "<p id='p" + paragraphNumber + "' style='display: none;'>Paragraph #" + paragraphNumber + "</p>";
		//This does the same, is perhaps cleaner:
		var newP = $("<p></p>").text('Paragraph #' + paragraphNumber).attr('id', 'p' + paragraphNumber).css({'display': 'none'});
		$('#essay').append(newP);
		
		$('#p' + paragraphNumber).slideDown(200);
		paragraphNumber++;
	});
});