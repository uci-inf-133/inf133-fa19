/*
	- Use jQuery to add a new paragraph each time the button is clicked. Give it the text "paragraph #", where # is the paragraph number.
	- Have each new paragraph slide in when it gets added.
*/

//jQuery uses document.ready to designate when the page has loaded
$(document).ready(()=> {
	
});