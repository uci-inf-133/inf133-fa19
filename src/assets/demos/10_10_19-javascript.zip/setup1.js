var array = [6, 2, 8, 1, 2, 5, 3];
console.log('Array is ' + array);

/*TODO:
- add a 4 to the end of the list and print it again
- calculate and print out the sum of all of the numbers in the array
- count how many even numbers are in the array
*/

