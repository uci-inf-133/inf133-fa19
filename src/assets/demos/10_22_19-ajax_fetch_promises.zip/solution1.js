/*
Necessary installation in order to run:
 - live-server, installed globally: https://www.npmjs.com/package/live-server
 - twitter-proxy, installed globally: https://www.npmjs.com/package/twitter-proxy
 - A developer Twitter account, with consumerKey and consumerSecret saved in a JSON file named twitter_proxy_config.json: https://developer.twitter.com/
 - Run the proxy with "twitter-proxy twitter_proxy_config.json"

Task:
 - Use fetch() to get tweets with the hashtag "UCI" via the twitter proxy (hashtag is encoded as %23)
 - Add the text of those tweets as list items to the unordered list
 - Twitter API reference: https://developer.twitter.com/en/docs/tweets/search/api-reference/get-search-tweets
*/

//JQuery document ready
$(() => {
	fetch('http://localhost:7890/1.1/search/tweets.json?q=%23UCI').then((response) => {
		response.json().then((json) => {
			json.statuses.forEach((s => {
				$('#list').append('<li>' + s.text + '</li>')
			}));
		});
	});
});